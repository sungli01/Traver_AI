# Skywork Voyage Intelligence (SVI)

Monorepo for SVI Project.

## Structure
- `apps/client`: Next.js frontend (Vercel)
- `apps/server`: Node.js backend (Railway)
- `packages/shared`: Common types and schemas
